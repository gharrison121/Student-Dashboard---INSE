# Student-Dashboard---INSE

This project consists of our coursework for the unit 'Introduction To Software Engineering' and makes up 50% of our final grade.